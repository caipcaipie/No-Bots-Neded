import discord
import asyncio
import os
import keep_alive
from discord.ext import commands
import random
from datetime import *
import aiohttp
import requests
import json
from disputils import BotEmbedPaginator


TOKEN = os.environ.get('bot_token')
startdate = 0

# JagTheFriend: okay rip j
print("su" + "p" * 200)  #keep this please

PREFIX_PATH = "./prefixes.json"


# to get the prefix
def get_prefix(client, message):
    with open(PREFIX_PATH, "r") as f:
        prefixes = json.load(f)
    return prefixes.get(str(message.guild.id), "?")


client = commands.Bot(command_prefix=get_prefix)


# to see whether the bot is running or not
@client.event
async def on_ready():
    '''shows that the bot is working'''

    print("\n\nIts working !!\n\n")


# when bot is added to other server
@client.event
async def on_guild_join(guild):
    with open(PREFIX_PATH, "r") as f:
        prefixes = json.load(f)

    prefixes[str(guild.id)] = "?"

    # storing the data
    with open(PREFIX_PATH, "w") as f:
        json.dump(prefixes, f, indent=4)


# when bot removed from server
@client.event
async def on_guild_remove(guild):
    with open(PREFIX_PATH, "r") as f:
        prefixes = json.load(f)

    prefixes.pop(str(guild.id))

    # storing the data
    with open(PREFIX_PATH, "w") as f:
        json.dump(prefixes, f, indent=4)


@client.command()
@commands.has_permissions(administrator=True)
async def change_prefix(ctx, prefix):
    """To allow the prefix to be changed"""

    with open(PREFIX_PATH, "r") as f:
        prefixes = json.load(f)

    prefixes[str(ctx.guild.id)] = prefix
    # storing the data
    with open(PREFIX_PATH, "w") as f:
        json.dump(prefixes, f, indent=4)

    await ctx.send(f"Prefix has been changed to **{prefix}**")


@change_prefix.error
async def info_error(ctx, error):
    """To deal with errors associated with the change_prefix"""

    if isinstance(error, commands.errors.MissingPermissions):
        await ctx.send(f"You don't have the admin perms <@{ctx.author.id}>")


@client.event
async def on_ready():
    await client.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching,
            name=f"{len(client.guilds)} servers"))

    global startdate
    startdate = datetime.now()

    print(f'{client.user} has connected to Discord!')


# says hi
@client.event
async def on_message(message):
    if str(message.content) == "how are you ?":
        await message.channel.send("I'm gud thx, and hbu ?")

    if str(message.content) == "im good thanks":
        await message.channel.send("Noice")

    if str(message.content) == "im sad":
        await message.channel.send("why hope you get better")

    await client.process_commands(message)


# says pong back
@client.command()
async def say(ctx, *args):
    await ctx.send('{} arguments: {}'.format(len(args), ', '.join(args)))


# warns user
@client.command()
async def warn(ctx, user, *arg):
    if arg:
        await ctx.send(f"{user} was warned for {' '.join(arg)}")
    else:
        await ctx.send(f"{user} was warned")


@client.command()
async def cal(ctx, formula):
    await ctx.send(f"Result: {eval(formula)}")


@client.command()
async def game(ctx):
    number = random.randint(0, 10)
    for guess in range(0, 5):
        await ctx.send('guess')
        Message = await client.wait_for('message')
        print(Message)

        Message = int(Message)

        if Message.cleant_content > number:
            await ctx.send('bigger')

        elif Message.cleant_content < number:
            await ctx.send('smaller')

        else:
            await ctx.send('true')


@client.command(pass_context=True)
async def mute(ctx, member: discord.Member):

    role = discord.utils.get(member.server.roles, name='Muted')
    await client.add_roles(member, role)

    embed = discord.Embed(
        title="User Muted!",
        description="**{0}** was muted by **{1}**!".format(
            member, ctx.message.author),
        color=0xff00f6)
    await client.say(embed=embed)


#Returns User stats for the server
@client.command()
async def user(ctx, member: discord.User = None):
    if member == None:
        member = ctx.message.author
        pronoun = "Your"
    else:
        pronoun = "Their"
    name = f"{member.name}#{member.discriminator}"
    joined = member.joined_at
    role = member.top_role
    await ctx.channel.send(
        f"{pronoun} name is {name}, They joined at {joined}, {pronoun} rank is {role}"
    )


@client.command()
async def ping(ctx):
    embed = discord.Embed(
        title="ping", description="tell you the bots ping", color=0x00ff00)
    embed.add_field(
        name="Value:", value=f"{round(client.latency * 1000)}", inline=False)

    await ctx.send(embed=embed)


@client.command()
async def gstart(ctx, mins, winners, *, prize):
    embed = discord.Embed(
        title="Giveaway!", description=f"**Prize:** {prize}", color=0x14458e)

    embed.set_footer(
        text=
        f"{winners} winners | Ends at: {datetime.utcnow()+timedelta(seconds=int(mins))} UTC"
    )

    await ctx.channel.purge(limit=1)
    my_msg = await ctx.send(embed=embed)
    await my_msg.add_reaction("🎉")

    await asyncio.sleep(int(mins))
    new_msg = await ctx.channel.fetch_message(my_msg.id)
    users = await new_msg.reactions[0].users().flatten()
    users.pop(users.index(client.user))
    number = 0
    while (number < len(winners)):
        winner = random.choice(users)
        await ctx.send(f'Congrats {winner.mention}!')


@client.command(name="len")
async def len_(ctx, *message):
    await ctx.send(
        f"<@{ctx.author.id}> {' '.join(message)} has {len(' '.join(message))} letters"
    )


@client.command(pass_context=True)
async def meme(ctx):
    embed = discord.Embed(title="meme", description="test")

    async with aiohttp.ClientSession() as cs:
        async with cs.get(
                'https://www.reddit.com/r/dankmemes/new.json?sort=hot') as r:
            res = await r.json()

            embed.set_image(url=res['data']['children'][random.randint(0, 25)]
                            ['data']['url'])

            # embed.add_field(name = "meme", value = res['data']['children'] [random.randint(0, 25)]['data']['url'], inline = False)

            await ctx.send(embed=embed)


@commands.has_permissions(ban_members=True)
@client.command()
async def ban(ctx, member: discord.Member, *, reason=None):
    await member.ban(reason=reason)
    await ctx.send(f'{member} has been banned!')


@client.event
async def on_member_join(ctx, *, member):
    channel = member.server.get_channel("channel id")
    fmt = 'Welcome to the {1.name} Discord server, {0.mention}'
    await ctx.send_message(channel, fmt.format(member, member.server))


@client.event
async def on_member_remove(ctx, *, member):
    ctx.send(f"{member} just left")


@commands.has_permissions(ban_members=True)
@client.command()
async def kick(ctx, member: discord.Member):

    await member.kick()

    await ctx.message.add_reaction(" ")

    await ctx.send(f"{member.name} has been kicked by {ctx.author.name}!")

    await log_channel.send(
        f"{ctx.author.name} has kicked {member.display_name}")


@client.command(aliases=["Temperature", "temperature"])
async def temp(ctx, *city_):
    city = " ".join(city_)
    url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid=ac7c75b9937a495021393024d0a90c44&units=metric'

    try:
        res = requests.get(url)

        data = res.json()

        temp = data['main']['temp']
        wind_speed = data['wind']['speed']

        latitude = data['coord']['lat']
        longitude = data['coord']['lon']

        descriptions = data['weather'][0]['description']

        embed = discord.Embed(
            title=f"Temperature of {city}",
            description=f"Temperature = {temp}°C",
            color=discord.Color.blurple())

        embed.add_field(name='Wind Speed', value=f' {wind_speed} m/s')

        embed.add_field(name='Latitude', value=f' {latitude}')
        embed.add_field(name='Longitude', value=f' {longitude}')

        embed.add_field(name='Description', value=f' {descriptions}')

        await ctx.send(embed=embed)

    except Exception:
        embed = discord.Embed(
            title=f"Error",
            description=
            f"Command Failed, Reason: Invaild City name | Or API Dose not understand",
            color=discord.Color.blurple())

        await ctx.send(embed=embed)


@client.command()
async def info(ctx):
    '''gives some information of the server'''

    name = str(ctx.guild.name)
    # desciption of the server
    description = "This server was meant for group studying and having fun" or str(
        ctx.guild.description)

    owner = str(ctx.guild.owner)  # owner name
    region = str(ctx.guild.region)  # server location

    member_count = str(ctx.guild.member_count)  # total members
    icon = str(ctx.guild.icon_url)  # server icon

    id_ = str(ctx.guild.id)
    embed = discord.Embed(
        title=f"{name} Server information",
        description=description,
    )

    embed.set_thumbnail(url=icon)  # the icon of the server
    embed.add_field(name="Owner", value=owner, inline=True)

    embed.add_field(name="Server id", value=id_, inline=True)
    embed.add_field(name="Region", value=region, inline=True)

    embed.add_field(name="Member count", value=member_count, inline=True)

    # sending the embed
    await ctx.send(embed=embed)


@client.command(aliases=["whois"])
async def userinfo(ctx, member: discord.Member = None):
    if not member:  # if member is no mentioned
        member = ctx.message.author  # set member as the author
    embed = discord.Embed(
        colour=discord.Colour.purple(),
        timestamp=ctx.message.created_at,
        title=f"User Info - {member}")
    embed.set_thumbnail(url=member.avatar_url)
    embed.set_footer(text=f"Requested by {ctx.author}")

    embed.add_field(name="ID:", value=member.id)
    embed.add_field(name="Display Name:", value=member.display_name)

    embed.add_field(
        name="Created Account On:",
        value=member.created_at.strftime("%a, %#d %B %Y, %I:%M %p UTC"))
    embed.add_field(
        name="Joined Server On:",
        value=member.joined_at.strftime("%a, %#d %B %Y, %I:%M %p UTC"))

    await ctx.send(embed=embed)


@client.command(aliases=['in'])
async def invite(ctx):
    """To allow people to invite this bot to other servers"""

    embed = discord.Embed(title='**Invite**', colour=discord.Color.blue())

    embed.add_field(
        name='No Bots Needed#2975',
        value=
        'If you would like to invite me! \n[Click Here](https://discord.com/api/oauth2/authorize?client_id=782270717168582678&permissions=0&scope=bot)',
        inline=True)

    embed.set_thumbnail(
        url=
        'https://cdn.discordapp.com/avatars/782270717168582678/6ecb133a2fbfa7f23b3a1118bcbc1d6b.webp?size=1024'
    )

    embed.set_footer(
        text='Bot created by dragon_cai#2152 and JagTheFriend#9984')

    await ctx.send(embed=embed)


@client.command(aliases=['delete'])
async def deleate(ctx, number: int = 1):
    '''deleats the above messages'''

    print(f"{ctx.author} wants {number} messages to be deleted")

    try:
        author = ctx.author.id  # the author
        # only works if i use it
        if str(ctx.author) == "JagTheFriend#9984":

            # only delete 30 messages at a time
            if number <= 31:  # 31, including the !delete command
                if number == 1:
                    number += 1
                await ctx.channel.purge(limit=number)

            else:
                await ctx.send(
                    f'I can\'t delete {number} messages !\n<@!{author}>')

        else:  # if the user does not have permission to delete, then it wouldn't work
            await ctx.send(f'You can\'t use that command <@{author}>')

    # error would occur if the command was used in dm
    except AttributeError:
        await ctx.send(f'You can\'t use that command <@{author}>')


@client.command()
async def clean(ctx, number):
    await ctx.channel.purge(limit=int(20))
    await ctx.send("Mission accomplished")


@client.command(name="spam")
async def _spammer(ctx, count: int, _spam_text: str):
    if _spam_text == "hi":
        await ctx.send(_spam_text)

    for i in range(count):
        await ctx.send(_spam_text)


client.remove_command("help")


# the help command
@client.command()
async def help(ctx):
    ecomic_commands = """
   
    """
    fun = """
?cal
?game

?help
?info

?invite
?ping

?temp
?user or ?userinfo or whois

?help
?say

?meme
?invite
    """

    moderator = """
?ban
?change_prefix

?clean
?deleate

?gstart
?kick

?len
?mute

?spam
?warn 
	"""

    await ctx.send("Click the arrows to navigate through the commands! **Prefix is ?**")

    embeds = [
        discord.Embed(title="Here are all the commands",
                    description="Click the arrows to navigate through the commands"),

        discord.Embed(title="Fun commands: ",
                    description=fun),

        discord.Embed(title="Moderator commands: ",
                    description=moderator),            
    ]

    paginator = BotEmbedPaginator(ctx, embeds)
    await paginator.run()


mainshop = [
    {"name": "Watch", "price": 30, "description": "Time"},
    {"name": "Tv", "price": 340, "description": "Watch movies etc"},
    {"name": "Computer", "price": 90, "description": "To get memes"},
    {"name": "Laptop", "price": 60,
        "description": "To bet coins on memes which you think would be popular"}
]

# check the balance
@client.command(aliases=["bal"])
async def balance(ctx):
    await open_account(ctx.author)

    users = await get_bank_data()

    wallet_amt = users[str(ctx.author.id)]["wallet"]
    bank_amt = users[str(ctx.author.id)]["bank"]

    embed = discord.Embed(
        title=f"{ctx.author}'s balance",
        color=discord.Color.red()
    )

    embed.add_field(name="Wallet balance:", value=wallet_amt)
    embed.add_field(name="Bank balance:", value=bank_amt)

    # sending the embed
    await ctx.channel.send(embed=embed)


@client.command()
async def beg(ctx):
    await open_account(ctx.author)

    users = await get_bank_data()

    if random.randint(0, 10) == 2:
        # earning would be randomley picked
        earnings = random.randint(0, users[str(ctx.author.id)]["wallet"])

        users[str(ctx.author.id)]["wallet"] += earnings

        await ctx.channel.send(f"Someone gave you {earnings} coins !!")
        # storing the values
        with open("mainbank.json", "w") as f:
            json.dump(users, f)

    else:    
        await ctx.channel.send(f"You didn't recive anything lol <@{ctx.author.id}>")


# to allow user to send money to another user
@client.command()
async def send(ctx, member: discord.Member, amount=None):
    # check whether account exists
    await open_account(ctx.author)
    await open_account(member)

    if amount == None:  # no amount is given
        await ctx.channel.send(f'Please enter a amount !! <@{ctx.author.id}>')
        return

    if int(amount) < 0:  # negative amount is given
        await ctx.channel.send(f'Please enter a _positive amount_ !! <@{ctx.author.id}>')
        return

    # getting wallet, bank details
    bal = await update_bank(ctx.author)

    # 0 --> wallet
    # 1 --> bank

    amount_ = int(amount)
    if amount_ > bal[0]:
        await ctx.channel.send(f"You don't have enough funds !!! <@{ctx.author.id}>")
        return

    # person who sends
    await update_bank(ctx.author, -1*amount_)

    # the person who recives
    await update_bank(member, amount_,)

    # telling that he/she has given <amount_> to him/her
    await ctx.channel.send(f"<@{ctx.author.id}> gave {amount_} coins to <@{member.id}> !!")


# to allow user to send money to another user
@client.command()
async def rob(ctx, member: discord.Member, amount=0):
    # check whether account exists
    await open_account(ctx.author)
    await open_account(member)

    # getting wallet, bank details
    bal = await update_bank(member)

    # 0 --> wallet
    # 1 --> bank
    if bal[0] < 30:
        await ctx.channel.send(f"Its not worth it... <@{ctx.author.id}>")
        return

    if int(amount) == 0:
        earnings = random.randint(0, bal[0])
        amount = earnings

    if random.randint(1, 4):
        # the person who receives
        await update_bank(ctx.author, earnings)

        # the person who losses
        await update_bank(member, -1*earnings)

        # telling that he/she has given <amount_> to him/her
        await ctx.channel.send(f"<@{ctx.author.id}> robbed <@{member.id}> for {amount} coins !!!")

    else:
        # the person who receives
        await update_bank(ctx.author, earnings)

        # the person who losses
        await update_bank(ctx.author, -1*earnings)

        # telling that he/she has given <amount_> to him/her
        reaction_ = random.choice([":joy:", ":rofl:"])
        await ctx.channel.send(f"<@{ctx.author.id}> lost {amount} coins to <@{member.id}> {reaction_}")


# to show the things user could buy
@client.command()
async def shop(ctx):
    embed = discord.Embed(title="Shop", description="Things which you could buy: ")

    for item in mainshop:
        name = item["name"]
        price = item["price"]
        desc = item["description"]
        embed.add_field(name=name, value=f"${price} \n{desc}", inline=True)

    await ctx.channel.send(embed=embed)


# to allow user to buy stiff
@client.command()
async def buy(ctx, item, amount=1):
    await open_account(ctx.author)

    result = await buy_this(ctx.author, item, amount)

    if not result[0]:
        # if the item isn't there then:
        if result[1] == 1:
            await ctx.channel.send("That Object isn't there!")
            return

        # if there isn't enough money then
        if result[1] == 2:
            await ctx.channel.send(f"You don't have enough money in your wallet to buy {amount} {item}")
            return

    # showing what the user has bought
    await ctx.channel.send(f"You just bought {amount} {item}")


# to allow user to see what they  have bought
@client.command()
async def bag(ctx):
    await open_account(ctx.author)
    user = ctx.author
    users = await get_bank_data()

    try:
        # check whether the user has bought anything
        bag = users[str(user.id)]["bag"]
    except Exception:
        # user hasn't bought anything
        bag = []

    embed = discord.Embed(title="Bag")
    for item in bag:
        name = item["item"]
        amount = item["amount"]

        embed.add_field(name=name, value=amount)

    # showing the things user had bought
    await ctx.channel.send(embed=embed)


# all checks etc on the things user buyied occurs here
async def buy_this(user, item_name, amount):
    item_name = item_name.lower()
    name_ = None
    for item in mainshop:
        name = item["name"].lower()

        # check whether item exits
        if name == item_name:
            name_ = name
            price = item["price"]
            break

    # item doesn't exit
    if name_ == None:
        return [False, 1]

    # finding the total cost
    cost = price*amount

    users = await get_bank_data()

    bal = await update_bank(user)

    # checking whether the user has sufficient fund
    if bal[0] < cost:
        return [False, 2]

    try:
        index = 0
        t = None

        for thing in users[str(user.id)]["bag"]:
            n = thing["item"]

            if n == item_name:
                old_amt = thing["amount"]
                new_amt = old_amt + amount
                users[str(user.id)]["bag"][index]["amount"] = new_amt
                t = 1
                break

            index += 1

        if t == None:
            obj = {"item": item_name, "amount": amount}
            users[str(user.id)]["bag"].append(obj)

    except Exception:
        obj = {"item": item_name, "amount": amount}
        users[str(user.id)]["bag"] = [obj]

    with open("mainbank.json", "w") as f:
        json.dump(users, f)

    await update_bank(user, cost*-1, "wallet")

    return [True, "Worked"]


# to allow user to sell stuff
@client.command()
async def sell(ctx, item, amount=1):
    await open_account(ctx.author)

    res = await sell_this(ctx.author, item, amount)

    if not res[0]:
        if res[1] == 1:
            await ctx.channel.send("That Object isn't there!")
            return
        if res[1] == 2:
            await ctx.channel.send(f"You don't have {amount} {item} in your bag.")
            return
        if res[1] == 3:
            await ctx.channel.send(f"You don't have {item} in your bag.")
            return

    await ctx.channel.send(f"You just sold {amount} {item}.")


# to do checks on what the user is trying to sell
async def sell_this(user, item_name, amount, price=None):
    item_name = item_name.lower()
    name_ = None
    for item in mainshop:
        name = item["name"].lower()
        if name == item_name:
            name_ = name
            if price == None:
                price = 0.9 * item["price"]
            break

    if name_ == None:
        return [False, 1]

    cost = price*amount

    users = await get_bank_data()

    bal = await update_bank(user)

    try:
        index = 0
        t = None
        for thing in users[str(user.id)]["bag"]:
            n = thing["item"]

            # checking whether the item exists
            if n == item_name:

                # the cost of that item
                old_amt = thing["amount"]
                new_amt = old_amt - amount

                # checking whether there is enough funds
                if new_amt < 0:
                    return [False, 2]

                # changing the [total] amount to the new amount
                users[str(user.id)]["bag"][index]["amount"] = new_amt

                t = 1
                break

            # index is used for going through the bag
            index += 1

        if t == None:
            return [False, 3]

    except Exception:
        return [False, 3]

    # storing the data
    with open("mainbank.json", "w") as f:
        json.dump(users, f)

    # updating user's bank
    await update_bank(user, cost)

    # items were successfully sold
    return [True, "Worked"]


@client.command(aliases=["lb"])
async def leaderboard(ctx, x=1):
    users = await get_bank_data()
    leader_board = {}
    total = []
    for user in users:
        name = int(user)
        total_amount = users[user]["wallet"] + users[user]["bank"]
        leader_board[total_amount] = name
        total.append(total_amount)
    
    # sorting the total
    total = sorted(total, reverse=True)

    embed = discord.Embed(title=f"Top {x} Richest People",
                            description="This is decided on the basis of raw money in the bank and wallet", color=discord.Color(0xfa43ee))
    index = 1
    for amt in total:
        # runs until all the user are added
        id_ = leader_board[amt]
        member = client.get_user(id_)
        name = member.name
        embed.add_field(name=f"{index}. {name}",
                        value=f"{amt}",  inline=False)
        if index == x:
            break

        else:
            index += 1

    # sending the wmbed
    await ctx.channel.send(embed=embed)


# user robbing another user
@client.command(aliases=['slot'])
async def slots(ctx, amount=None):
    # check whether account exists
    await open_account(ctx.author)

    if amount == None:  # no amount is given
        await ctx.channel.send(f'Please enter a amount !! <@{ctx.author.id}>')
        return

    if int(amount) < 0:  # negative amount is given
        await ctx.channel.send(f'Please enter a _positive amount_ !! <@{ctx.author.id}>')
        return

    # getting bank details
    bal = await update_bank(ctx.author)

    # 0 --> wallet
    # 1 --> bank

    amount_ = int(amount)
    if amount_ > bal[0]:  # checking whether there is enough money
        await ctx.channel.send(f"You don't have enough funds !!! <@{ctx.author.id}>")
        return

    if 40 > bal[0]:  # checking whether there is enough money
        await ctx.channel.send(f"You need more than 420 coins !!!, \nConsider withdrawing some coins \n<@{ctx.author.id}>")
        return

    final = []
    for i in range(3):
        a = random.choice(["X", "O", "Q", "F"])
        final.append(a)

    # sending the list
    await ctx.channel.send(str(final))

    amount_to_win_losse = random.randint(0, 100)
    # check whether the user won or not
    if final[0] in (final[1], final[2]):
        await ctx.channel.send(f"You won {amount_*amount_to_win_losse} <@{ctx.author.id}> :partying_face:")
        # increase wallet balance
        await update_bank(ctx.author, amount_to_win_losse*amount_)
    else:
        await ctx.channel.send(f"You lost {amount_*amount_to_win_losse} <@{ctx.author.id}> :expressionless:")
        # decrease wallet balance
        await update_bank(ctx.author, -(amount_to_win_losse)*amount_)


# to deposit money
@client.command(aliases=['depo', 'deposit'])
async def dep(ctx, amount=None):
    # check whether account exists
    await open_account(ctx.author)

    if amount == None:  # no amount is given
        await ctx.channel.send(f'Please enter a amount !! <@{ctx.author.id}>')
        return

    if int(amount) < 0:  # negative amount is given
        await ctx.channel.send(f'Please enter a _positive amount_ !! <@{ctx.author.id}>')
        return

    # getting bank details
    bal = await update_bank(ctx.author)

    # 0 --> wallet
    # 1 --> bank

    amount_ = int(amount)
    if amount_ > bal[0]:
        await ctx.channel.send(f"You don't have enough funds !!! <@{ctx.author.id}>")
        return

    # decreasing wallet balance
    await update_bank(ctx.author, -1*amount_)

    # increasing bank balance, duality principle
    await update_bank(ctx.author, amount_, "bank")

    # telling that he/she has with drawn <amount_>
    await ctx.channel.send(f"You deposited {amount_} coins !! <@{ctx.author.id}>")


# to withdraw money
@client.command(aliases=['withdrew'])
async def withdraw(ctx, amount=None):
    # check whether account exists
    await open_account(ctx.author)

    if amount == None:  # no amount is given
        await ctx.channel.send(f'Please enter a amount !! <@{ctx.author.id}>')
        return

    if int(amount) < 0:  # negative amount is given
        await ctx.channel.send(f'Please enter a _positive amount_ !! <@{ctx.author.id}>')
        return

    # getting bank details
    bal = await update_bank(ctx.author)

    # 0 --> wallet
    # 1 --> bank

    amount_ = int(amount)
    if amount_ > bal[1]:
        await ctx.channel.send(f"You don't have enough funds !!! <@{ctx.author.id}>")
        return

    # increasing wallet balance
    await update_bank(ctx.author, amount_)

    # decreasing bank balance, duality principle
    await update_bank(ctx.author, -1*amount_, "bank")

    # telling that he/she has with drawn <amount_>
    await ctx.channel.send(f"You withdrew {amount_} coins !! <@{ctx.author.id}>")


# opening the account
async def open_account(user):
    users = await get_bank_data()

    # check whether a account is already open
    if str(user.id) in users:
        return False

    else:  # user doesn't have an account
        users[str(user.id)] = {}
        users[str(user.id)]["wallet"] = 50
        users[str(user.id)]["bank"] = 50

    # storing the values
    with open("mainbank.json", "w") as f:
        json.dump(users, f)

    # new account is made
    return True


async def get_bank_data():
    with open("mainbank.json", "r") as f:
        users = json.load(f)

    return users


# update the bank and wallet
async def update_bank(user, change=0.00, mode="wallet"):
    users = await get_bank_data()

    users[str(user.id)][mode] += change

    with open("mainbank.json", "w") as f:
        json.dump(users, f)

    bal = [users[str(user.id)]["wallet"], users[str(user.id)]["bank"]]
    return bal


client.run(TOKEN)

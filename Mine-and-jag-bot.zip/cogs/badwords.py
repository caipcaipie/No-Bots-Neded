import discord
from discord.ext import commands


class badwords(commands.Cog):
    def __init__(self, client):
        self.client = client
        self.bad_words = ["nigga", "fuck"] 


    @commands.Cog.listener()
    async def on_message(self, message):
        msg_content = str(message.content)
        for word in self.bad_words:
            if word.lower() in msg_content.lower():
                await message.delete()
                await message.channel.send(f"{message.author.mention} No Bad Words!")
                



def setup(client):
    client.add_cog(badwords(client))